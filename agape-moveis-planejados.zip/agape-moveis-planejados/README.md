# Agape Móveis Planejados

Site institucional responsivo para a Agape, com foco em apresentar ambientes e gerar pedidos de orçamento pelo WhatsApp.

## Dados configurados
- Empresa: Agape Móveis Planejados
- WhatsApp: `5565996852876`
- Região: Rosário Oeste e Nobres, Mato Grosso
- Direção visual: sofisticada e moderna, tons naturais, verde-oliva, creme e tipografia editorial
- Referência de estrutura: https://valenceplanejados.com.br/

## Estrutura
- `index.html` — conteúdo, seções e formulário de orçamento
- `styles.css` — identidade visual responsiva
- `script.js` — menu mobile e envio das informações para o WhatsApp

## Como testar
Abra `index.html` no navegador. Para testar o orçamento, preencha o formulário e envie; o navegador abrirá o WhatsApp com a mensagem pronta para revisão.

## Publicar no GitHub
1. Acesse https://github.com/new
2. Crie um repositório chamado `agape-moveis-planejados`.
3. Não selecione o projeto `mt-web-connect` nem importe seus arquivos.
4. Envie os três arquivos do site e este README para o novo repositório.
5. Para publicar gratuitamente, pode usar GitHub Pages nas configurações do repositório (Settings → Pages).

## Antes de publicar para clientes
- Substituir as imagens ilustrativas por fotos reais de projetos da Agape, com autorização.
- Confirmar quais materiais, garantias, prazos e serviços a empresa oferece antes de anunciar esses diferenciais.
- Testar o WhatsApp no celular e no computador.
- Adicionar domínio próprio, se houver.

## Observação
Este é um protótipo inicial estático. Não inclui painel administrativo, banco de dados ou sistema de gestão de leads.
